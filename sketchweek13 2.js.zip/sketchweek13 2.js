var characterX = 200;
var characterY = 200;
var w = 95; 
var s = 95;
var a = 55;
var d = 45;
var shapeX = 100;
var shapeY = 30;
var shapeXSpeed;
var shapeYSpeed;
var mouseShapeX;
var mouseShapeY;

function setup()
{
    createCanvas(300, 400);
    // get a random speed when the it first starts
    shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 10)) + 1);
    shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 10)) + 1);
    shapeXs[i] = getRandomNumber(250);
    shapeYs[i] = getRandomNumber(300);
    diameters[i] = getRandomNumber(20);
}
createCharacter(200, 350);
}
function draw() {
    background(130, 50, 85);
    stroke(0);
    fill(0);

    // call createBorders function
    createBorders(10);

    // exit message
    textSize(16);
    text("EXIT", width - 25, height - 25)

    //createCharacter(200,350);
    drawCharacter();
    characterMovement();

    fill(20, 175, 20);
    // draw the shape
    for (var i = 0; i < shapeXs.length; i++) {
        circle(shapeXs[i], shapeYs[i], diameters[i]);
        shapeXSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
        shapeYSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);




        // move the shape
        shapeXs[i] += shapeXSpeeds[i];
        shapeYs[i] += shapeYSpeeds[i];
        // check to see if the shape has gone out of bounds
        if (shapeXs[i] > width) {
            shapeXs[i] = 0;
        }
        if (shapeXs[i] < 0) {
            shapeXs[i] = width;
        }
        if (shapeYs[i] > height) {
            shapeYs[i] = 0;
        }
        if (shapeYs[i] < 0) {
            shapeYs[i] = height;
        }
    }
    // check to see if the character has left the exit
    if (characterX > width && characterY > width - 50) {
        fill(0);
        stroke(5);
        textSize(26);
        text("You Win!", width / 3 - 75, height / 3 - 75);
    }

    // create the shape based on the mouse click
    fill(120, 130, 140);
    circle(mouseShapeX, mouseShapeY, 25);
}

function draw() {
    background(120, 45, 78);
    stroke(0);
    fill(0);

    // call createBorders function
    createBorders(10);

    // exit message
    textSize(16);
    text("EXIT", width - 50, height - 50)

    //createCharacter(200,350);
    drawCharacter();
    characterMovement();

function draw() {
    background(120, 45, 78);
    stroke(0);
    fill(0);

    // call createBorders function
    createBorders(10);

    // exit message
    textSize(16);
    text("EXIT", width - 50, height - 50)

    //createCharacter(200,350);
    drawCharacter();
    characterMovement();
function draw()
{
    background(120,45,78);
    stroke(0);
    fill(0);
    // top border
    rect(0,0,width,10);
    // left border
    rect(0,0,10,height);
    // bottom border
    rect(0, height-10,width, 10);
    // right upper border
    rect(width-10,0,10,height-50);

    textSize(25);
    text("EXIT", width-50,height-50)

    fill(20, 75, 200);
    circle(characterX,characterY,25);

    if(keyIsDown(w))
    {
        characterY -= 10;   
    }
    if(keyIsDown(s))
    {
        characterY += 5;   
    }
    if(keyIsDown(a))
    {
        characterX -= 2;   
    }
    if(keyIsDown(d))
    {
        characterX += 20;   
    }
    
    fill(255, 204, 0);
    circle(shapeX, shapeY, 40);

    shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
    shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
   

    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;

    if(shapeX > width)
    {
        shapeX = 0;
    }
    if(shapeX < 0)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 0;
    }
    if(shapeY < 0)
    {
        shapeY = height;
    }

    if(characterX > width && characterY > width-50)
    {
        fill(0);
        stroke(5);
        textSize(50);
        text("You Win!", width/2-50, height/2-50);
    }

    fill(255, 204, 0);
    circle(mouseShapeX, mouseShapeY, 25);
}

{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
